﻿using Library.project.Tabs;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MAUI.project.ViewModels
{
    public class MainViewModel
    {
    }
}
